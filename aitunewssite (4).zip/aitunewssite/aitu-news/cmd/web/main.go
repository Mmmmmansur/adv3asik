package main

import (
	"database/sql"
	"flag"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/gorilla/mux"
	"html/template"
	"log"
	"net/http"
	"os"
	"path/filepath"
)

func init() {

	//шаблон
	// Измените расширение файлов шаблонов на .html.tmpl
	tpl = template.Must(template.ParseGlob("ui/templates/*.html"))

}

// structure of web application
type application struct {
	errorLog  *log.Logger
	infoLog   *log.Logger
	templates *template.Template
}

type User struct {
	Title   string `json:"title"`
	Summary string `json:"summary"`
}

func main() {

	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/golang")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	_, err = db.Exec("CREATE TABLE IF NOT EXISTS departments (id INT PRIMARY KEY, dep_name VARCHAR(50), staff_quantity INT)")
	if err != nil {
		log.Fatal(err)
	}

	//insert, err := db.Query("INSERT INTO `news` (`title`, `summary`) VALUES ('Alex', 25)")
	//if err != nil {
	//	panic(err)
	//}
	//defer insert.Close()//

	res, err := db.Query("SELECT `title`, `summary` FROM `news`")
	if err != nil {
		panic(err)
	}

	for res.Next() {
		var user User
		err = res.Scan(&user.Title, &user.Summary)
		if err != nil {
			panic(err)

			fmt.Println(fmt.Sprintf("User: %s with summary %d", user.Title, user.Summary))
		}
	}

	defer res.Close()

	//command-line flags
	addr := flag.String("addr", "127.0.0.1:4000", "HTTP network address")
	flag.Parse()

	//loggers
	infoLog := log.New(os.Stdout, "INFO\t", log.Ldate|log.Ltime)
	errorLog := log.New(os.Stderr, "ERROR\t", log.Ldate|log.Ltime|log.Lshortfile)

	//application instance
	app := &application{
		errorLog: errorLog,
		infoLog:  infoLog,
	}

	//Gorilla Mux router
	router := mux.NewRouter()

	//handlers for pages
	router.HandleFunc("/", IndexHandler).Methods("GET")
	router.HandleFunc("/category", CategoryHandler).Methods("GET")
	router.HandleFunc("/contact", ContactHandler).Methods("GET")
	router.HandleFunc("/single", SingleHandler).Methods("GET")
	router.HandleFunc("/create-news", CreateNewsHandler).Methods("GET", "POST")
	router.HandleFunc("/success", SuccessHandler).Methods("GET")
	router.HandleFunc("/create-department", CreateDepartmentHandler).Methods("GET", "POST")
	router.HandleFunc("/departments", ShowDepartmentsHandler).Methods("GET", "POST")
	router.HandleFunc("/registration", RegistrationHandler).Methods("GET", "POST")
	router.HandleFunc("/login", LoginHandler).Methods("GET", "POST")
	router.HandleFunc("/approve-teacher-role", ApproveTeacherRole).Methods("POST")
	router.HandleFunc("/Article", ArticleHandler).Methods("GET", "POST")

	//static CSS files
	http.HandleFunc("/ui/static/css/", func(w http.ResponseWriter, r *http.Request) {
		filePath := "C:/Users/Мансур/Desktop/aitunewssite/aitu-news/cmd/web/ui/static" + r.URL.Path[len("/ui/static/css/"):]
		http.ServeFile(w, r, filePath)
	})

	//static files from the "ui/static/" directory
	router.PathPrefix("/static/").Handler(http.StripPrefix("/static/", http.FileServer(http.Dir("ui/static/"))))

	//current project directory
	dir, err := os.Getwd()
	if err != nil {
		app.errorLog.Fatal(err)
	}

	//path to the templates directory
	templatesPath := filepath.Join(dir, "ui/templates")

	//list of template files
	templateFiles, err := filepath.Glob(filepath.Join(templatesPath, "*.html"))
	if err != nil {
		app.errorLog.Fatal(err)
	}

	//templates from files
	templates, err := template.ParseFiles(templateFiles...)
	if err != nil {
		app.errorLog.Fatal(err)
	}

	//templates in your application
	app.templates = templates

	//router to the default HTTP handler
	http.Handle("/", router)

	//HTTP server
	srv := &http.Server{
		Addr:     *addr,
		ErrorLog: errorLog,
		Handler:  router,
	}

	//server start
	infoLog.Printf("Starting server on %s", *addr)
	err = srv.ListenAndServe()
	errorLog.Fatal(err)

}
