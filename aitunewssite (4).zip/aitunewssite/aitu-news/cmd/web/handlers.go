package main

import (
	"database/sql"
	"github.com/gorilla/sessions"
	"golang.org/x/crypto/bcrypt"
	"html/template"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	_ "github.com/go-sql-driver/mysql"
)

var tpl *template.Template
var db *sql.DB
var store = sessions.NewCookieStore([]byte("your-secret-key"))

type Test struct {
	id int64
}
type AllIDS struct {
	ID []*Test
}

type News struct {
	ID      int
	Title   string
	Summary string
}

func HashPassword(password string) (string, error) {
	// Генерируем хэш пароля
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	return string(hashedPassword), nil
}

// CheckPassword проверяет, соответствует ли переданный хэш паролю.
func CheckPassword(password, hashedPassword string) bool {
	// Сравниваем хэш пароля с хэшированным паролем в базе данных
	err := bcrypt.CompareHashAndPassword([]byte(hashedPassword), []byte(password))
	return err == nil
}

// RegistrationHandler обрабатывает регистрацию пользователя.
func RegistrationHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		// Получаем данные из формы
		fullName := r.FormValue("full_name")
		email := r.FormValue("email")
		password := r.FormValue("password")
		role := r.FormValue("role")

		// Валидация данных
		if fullName == "" || email == "" || password == "" || role == "" {
			http.Error(w, "Все поля обязательны для заполнения", http.StatusBadRequest)
			return
		}

		// Проверяем формат электронной почты
		if !isValidEmail(email) {
			http.Error(w, "Некорректный формат электронной почты", http.StatusBadRequest)
			return
		}

		// Хэшируем пароль
		hashedPassword, err := HashPassword(password)
		if err != nil {
			http.Error(w, "Ошибка хэширования пароля", http.StatusInternalServerError)
			return
		}

		// Вставляем нового пользователя в базу данных
		_, err = db.Exec("INSERT INTO users (full_name, email, hashed_password, role) VALUES (?, ?, ?, ?)", fullName, email, hashedPassword, role)
		if err != nil {
			http.Error(w, "Ошибка регистрации пользователя", http.StatusInternalServerError)
			return
		}

		// Редирект на страницу успеха
		http.Redirect(w, r, "/success", http.StatusSeeOther)
		return
	}

	// Отображаем форму регистрации
	err := tpl.ExecuteTemplate(w, "registration.html", nil)
	if err != nil {
		http.Error(w, "Ошибка отображения страницы регистрации", http.StatusInternalServerError)
		return
	}
}
func LoginHandler(w http.ResponseWriter, r *http.Request) {
	var email, password string // Объявляем переменные здесь

	if r.Method == http.MethodPost {
		// Получаем данные из формы
		email = r.FormValue("email")
		password = r.FormValue("password")

		// Получаем хэшированный пароль из базы данных
		var dbPassword, dbRole string
		err := db.QueryRow("SELECT hashed_password, role FROM users WHERE email = ?", email).Scan(&dbPassword, &dbRole)
		if err != nil {
			if err == sql.ErrNoRows {
				http.Error(w, "Неверный электронный адрес или пароль", http.StatusUnauthorized)
				return
			}
			http.Error(w, "Ошибка при запросе к базе данных", http.StatusInternalServerError)
			return
		}

		// Проверяем, соответствует ли введенный пароль хэшированному паролю из базы данных
		if !CheckPassword(password, dbPassword) {
			http.Error(w, "Неверный электронный адрес или пароль", http.StatusUnauthorized)
			return
		}

		// Создаем куки с ролью пользователя
		cookie := http.Cookie{
			Name:     "role",
			Value:    dbRole,
			Path:     "/",  // Установите необходимые параметры куки, например, срок жизни, путь и домен, если требуется
			MaxAge:   3600, // Пример: куки действительны в течение 1 часа
			HttpOnly: true, // Для безопасности, чтобы куки недоступны из JavaScript
		}
		http.SetCookie(w, &cookie)

		// страницa успеха
		http.Redirect(w, r, "/success", http.StatusSeeOther)
		return
	}

	// Отображаем форму входа
	err := tpl.ExecuteTemplate(w, "login.html", nil)
	if err != nil {
		http.Error(w, "Ошибка отображения страницы входа", http.StatusInternalServerError)
		return
	}
}

// isValidEmail checks the validity of an email address.
func isValidEmail(email string) bool {
	return strings.Contains(email, "@")
}

// Обработчик для главной страницы
func IndexHandler(w http.ResponseWriter, r *http.Request) {
	// Запрос на получение всех новостей из базы данных
	rows, err := db.Query("SELECT id, title, summary FROM news")
	if err != nil {
		http.Error(w, "Ошибка при получении новостей", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var newsList []News
	// Итерация по результатам запроса и заполнение списка новостей
	for rows.Next() {
		var n News
		err := rows.Scan(&n.ID, &n.Title, &n.Summary)
		if err != nil {
			http.Error(w, "Ошибка при сканировании результатов запроса", http.StatusInternalServerError)
			return
		}
		newsList = append(newsList, n)
	}
	if err := rows.Err(); err != nil {
		http.Error(w, "Ошибка при итерации по результатам запроса", http.StatusInternalServerError)
		return
	}

	// Передача списка новостей в шаблон для отображения
	err = tpl.ExecuteTemplate(w, "index.html", newsList)
	if err != nil {
		http.Error(w, "Ошибка отображения главной страницы", http.StatusInternalServerError)
		return
	}
}

func CategoryHandler(w http.ResponseWriter, r *http.Request) {
	err := tpl.ExecuteTemplate(w, "category.html", nil)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

func ContactHandler(w http.ResponseWriter, r *http.Request) {
	err := tpl.ExecuteTemplate(w, "contact.html", nil)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

func SingleHandler(w http.ResponseWriter, r *http.Request) {
	err := tpl.ExecuteTemplate(w, "single.html", nil)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

func CreateNewsHandler(w http.ResponseWriter, r *http.Request) {
	if !isTeacher(r) {
		http.Error(w, "Only teachers can add news", http.StatusForbidden)
		return
	}
	if r.Method == http.MethodPost {
		title := r.FormValue("title")
		summary := r.FormValue("summary")

		_, err := db.Exec("INSERT INTO news (title, summary) VALUES (?, ?)", title, summary)
		if err != nil {
			http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			return
		}
		http.Redirect(w, r, "/success", http.StatusSeeOther)

		return
	}

	err := tpl.ExecuteTemplate(w, "create-news.html", nil)
	if err != nil {
		http.Error(w, "Ошибка отображения формы создания новости", http.StatusInternalServerError)
		return
	}
}

func isTeacher(r *http.Request) bool {

	cookie, err := r.Cookie("role")
	if err != nil {
		return false // Если куки не установлены или произошла ошибка, возвращаем false
	}

	//роль пользователя.
	return cookie.Value == "teacher"
}

func ApproveTeacherRole(w http.ResponseWriter, r *http.Request) {
	// Проверяем, что пользователь, отправивший запрос, является администратором
	if !isAdmin(r) {
		http.Error(w, "Only admins can approve teacher role", http.StatusForbidden)
		return
	}

	// Получаем идентификатор пользователя, роль которого нужно одобрить
	userID := r.FormValue("user_id")

	// Предположим, что в вашей базе данных есть таблица users
	// с полем role, где хранится роль пользователя.
	// Обновляем запись в базе данных, присваивая пользователю роль "teacher".
	_, err := db.Exec("UPDATE users SET role = ? WHERE id = ?", "teacher", userID)
	if err != nil {
		http.Error(w, "Failed to approve teacher role", http.StatusInternalServerError)
		return
	}

	// Возвращаем успешный ответ
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("Teacher role approved successfully"))
}

func isAdmin(r *http.Request) bool {
	// Получаем сеанс пользователя из cookies
	session, err := store.Get(r, "session-name")
	if err != nil {
		// Обработка ошибки
		return false
	}

	// Проверяем, есть ли у сеанса информация о роли
	role, ok := session.Values["role"].(string)
	if !ok {
		// Роль не указана, пользователь не является администратором
		return false
	}

	// Проверяем, является ли роль администратором
	return role == "admin"
}

func SuccessHandler(w http.ResponseWriter, r *http.Request) {
	err := tpl.ExecuteTemplate(w, "success.html", nil)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

func CreateDepartmentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		depName := r.FormValue("dep_name")
		staffQuantity := r.FormValue("staff_quantity")

		row, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/golang")
		if err != nil {
			http.Error(w, "Error on Connection", http.StatusInternalServerError)
			return
		}
		defer row.Close()

		_, err = db.Exec("INSERT INTO departments (dep_name, staff_quantity) VALUES (?, ?)", depName, staffQuantity)
		if err != nil {
			http.Error(w, "Error on Insert", http.StatusInternalServerError)
			return
		}

		// Редирект на страницу со всеми отделами
		http.Redirect(w, r, "/departments", http.StatusSeeOther)
		return
	}

	err := tpl.ExecuteTemplate(w, "create-department.html", nil)
	if err != nil {
		http.Error(w, "Error Template Rendering", http.StatusInternalServerError)
		return
	}
}

type Departments struct {
	ID            int
	DepName       string
	StaffQuantity int
}

func ShowDepartmentsHandler(w http.ResponseWriter, r *http.Request) {
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/golang")
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	defer db.Close()

	rows, err := db.Query("SELECT id, dep_name, staff_quantity FROM departments")
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var departments []Departments
	for rows.Next() {
		var d Departments
		err := rows.Scan(&d.ID, &d.DepName, &d.StaffQuantity)
		if err != nil {
			http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			return
		}
		departments = append(departments, d)
	}

	err = tpl.ExecuteTemplate(w, "departments.html", departments)
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}

}

func init() {
	// Получаем текущую директорию проекта
	dir, err := os.Getwd()
	if err != nil {
		panic(err)
	}

	// Формируем абсолютный путь к директории с шаблонами
	templatesPath := filepath.Join(dir, "ui/templates")

	// Создаем список файлов шаблонов
	templateFiles, err := filepath.Glob(filepath.Join(templatesPath, "*.html"))
	if err != nil {
		panic(err)
	}

	// Загружаем шаблоны из файлов
	tpl, err = template.ParseFiles(templateFiles...)
	if err != nil {
		panic(err)
	}

	// Инициализируем соединение с базой данных
	db, err = sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/golang")
	if err != nil {
		panic(err)
	}
}
